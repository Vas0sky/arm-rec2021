﻿=========================
 Ferrari 308 gt4 Pioneer
=========================

BY:
            /\
       ____/  \____
      |      U     |
      |L          C|
      \      N     /
       \     O    /
        \    S   /
         \      /
          \    /
           \ K/
            \/

Luck Nos
==========================

Name      : Ferrari 308gt4pioneer
Date      : 01/02/2021
Top Speed : 69 kph (measured)
Rating    : professional
Sound     : original

This is the second car rebuild by Luck Nos,
member of the Italian forum Alias Revolt Master (https://www.aliasrevoltmaster.com/forum/index.php?sid=a39c6ac137a7b504c90d86d237c9052e).

I brought the famous Ferrari 308 gt4 Pioneer back to Revolt. This car, in reality, is famous for being the only Ferrari to be officially used in the world of Rally.
The most important victory was at the Tour de France Auto in 1982, won by this car and driven by Charles Pozzi.
  I took the model of the Ferrari 308 he made SKARMINATER　プレゼント and I modified it WIDELY:
   1 more FAITHFUL to the real model
   2 more details, such as the headlights and side air vents
   3 Ferrari stylized for the rally
   4 texture of the original rally car
   5 modified parameters to make it more powerful and more faithful to a rally car
   6 added original car audio

-------------------------------------------------------------------------------
   THANKS FOR THE BASE MODEL
Thank you SKARMINATER　プレゼント for making the base model of the Ferrari 308 gt4
-------------------------------------------------------------------------------

All rights reserved:
Created by Luck Nos
Texture and sound by Marco Repainter

If you want to modify the above car,
please add the name Luck Nos in the acknowledgements or in a file where you indicate the origin of that model.

SPECIAL THANKS:
Thanks to Marco Repainter for painting (textures) the car and for. You can find him active on discord or on the Italian forum (https://www.aliasrevoltmaster.com/forum/index.php?sid=a39c6ac137a7b504c90d86d237c9052e).
Thanks to SKARMINATER　プレゼント for making the base model of the Ferrari 308 gt4.

Have fun!!!

 _/\_
|luck|
 \  /
  \/   All rights reserved - Luck Nos
============================================