Information
-----------------
Track Name:	Super Speedway
Length:		454 meters
Difficulty	Easy
Author:		Saffron
Challenge time:	23:300 (Stock Pros)


Description
-----------------
Gran Turismo is a racing game franchise known by many, with its sheer quality of quantity being its key selling point. I mostly made this track because it seemed simple enough to do as an oval, and this game in particular lacked some simple, no-nonsense ovals. It had a fair bit of character in both GT2 and GT3 with how it was all set up, mostly thanks to the scenery. It was a shame it was one of the many tracks from that game that never made it past the early PS2-era, with Polyphony deciding to replace this with the lifeless Motegi Super Speedway.

The track is mostly accurate to the original (GT2), with some inconsistencies here and there. The bankings probably aren't perfect, nor are the elevation changes. But what matters is the environment, the layout and the detail makes it instantly recognizable. I spent countless hours driving around this track in the original game to make the recreation as close to the original as possible, and fill the gaps wherever they were required. A lot of textures are printscreens from the original game as well.

I've utilized custom properties among other features exclusive to recent RVGL patches. Touching the gravel and/or the inside of the track in general will slow you down significantly. On top of that, taking a pitstop to grab the star (if you're racing with powerups) will slow you down immensely as well.


Requirements
-----------------
You MUST use the latest RVGL patch to see the textures, and for the custom properties to work.


Credits
-----------------
The Internet and Polyphony Digital for the textures
The Blender Foundation for Blender
FBV and/or Lo Scassatore for the custom sounds
Marv, Huki and Martin for the Blender plug-in
The RVGL Team for RVGL
ARM for the camera nodes tutorial
Rick Brewster for Paint.NET


Permissions
-----------------
This track may not be distributed anywhere else outside of Re-Volt Zone and Re-Volt I/O content packs. You are welcome however, to convert this track to another game, just make sure to give credit to Polyphony Digital and myself.