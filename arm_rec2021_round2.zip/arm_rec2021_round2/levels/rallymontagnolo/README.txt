=========================
     Rally Montagnolo
=========================

BY:
            /\
       ____/  \____
      |      U     |
      |L          C|
      \      N     /
       \     O    /
        \    S   /
         \      /
          \    /
           \ K/
            \/

Luck Nos
==========================

Length: 1260 m
The track was created by Luck Nos for the 'Trackmakers Challenges' (https://forum.re-volt.io/viewtopic.php?f=20&t=1366) tournament.
The result of this work is a rally located through the mountains.
Run an exciting race on the ice and try to get to the finish line as quickly as possible!
Drive through the mountains and enjoy the fantastic winter scenery while remembering to press the accelerator pedal as long as possible!!!
See you at the finish line!!!

This is the second track made by Luck Nos,
member of the Italian forum Alias Revolt Master (https://www.aliasrevoltmaster.com/forum/index.php?sid=a39c6ac137a7b504c90d86d237c9052e).

All rights reserved:
Created by Luck Nos
Texture by Marco Repainter
Nodes and rideability by THE B!
If you want to take some models from this track,
please add the name Luck Nos in the acknowledgements or in a file where you indicate the origin of that model.

SPECIAL THANKS:
Thanks to Marco Repainter for painting (textures) the entire track. You can find him active on discord or on the Italian forum (https://www.aliasrevoltmaster.com/forum/index.php?sid=a39c6ac137a7b504c90d86d237c9052e).
Thanks to THE B! for adding the nodes, backtracks, directions, and so on. You can find him active mainly on the Italian forum (https://www.aliasrevoltmaster.com/forum/index.php?sid=a39c6ac137a7b504c90d86d237c9052e).
Thanks to Ciccio for the valuable advice he has given me, especially regarding the track properties file. You can find him active on discord or on the Italian forum (https://www.aliasrevoltmaster.com/forum/index.php?sid=a39c6ac137a7b504c90d86d237c9052e).
Finally, we would like to thank Gel38 for using one of his models (the tree model) which made the track even more wintry ;)

Have fun!!!

 _/\_
|luck|
 \  /
  \/   All rights reserved - Luck Nos
============================================