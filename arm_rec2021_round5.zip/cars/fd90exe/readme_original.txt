Subaru Impreza WRX STI RA
by Kirbyguy22
Type: Original
==
Top Speed: ~38MPH
Acceleration: Very fast
Handling: Understeery, much like the real one
==
Tools used:
Autodesk 3DS Max 2012
Adobe Photoshop CS5.1
Re-Volt
==
Yeah, it's been a while. Almost exactly a year since Venom Vector. Now it's 2013 and I've got some more to show.
My e-mail is kirbyguy22@yahoo.com in case you want to repaint it.
Final completion date: March 3, 2013 2:30 AM PDT