
This track is 'Quake! reversed', copied from 'Quake!'.
See <Re-Volt dir>\levels\quake\_readme.txt.
